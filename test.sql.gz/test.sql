-- Adminer 4.7.6 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(10) DEFAULT NULL,
  `is_long` tinyint(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `ixla` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(64) DEFAULT NULL,
  `firstname` varchar(64) DEFAULT NULL,
  `lastname` varchar(64) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `dob` int(10) DEFAULT NULL,
  `sex` int(1) DEFAULT NULL,
  `register` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`),
  KEY `password` (`password`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `nickname`, `firstname`, `lastname`, `email`, `phone`, `password`, `dob`, `sex`, `register`) VALUES
(1,	'JackRabbit',	'Алексей',	'Зайцев',	'dr.JackRabbit@yandex.ru',	'79152215686',	'$2y$10$8fTeduB.XwtQoM7k0qxeQugDvS3blluwPxs/vc5iSg1rIgBYL/ry6',	-79369200,	1,	1633610433),
(2,	'Kolosoft',	NULL,	NULL,	'kaa@yandex.ru',	NULL,	'$2y$10$vfghXehpKL/nfb5G76WTUebs5bx3iUUvd2Z1/sexb6o3sV2vuf7TC',	-71074800,	1,	1633690176),
(5,	'JoraVer',	NULL,	NULL,	'tbsf@mail.ru',	NULL,	'$2y$10$TPc9lV4RkWVCQ.KezNi3aO/tWsjJx3NTxTxQNKG1I/dyWY/.fmH1K',	7549200,	1,	1634123873),
(6,	'Nata',	NULL,	NULL,	'niva338@mail.ru',	NULL,	'$2y$10$642eV.kecub7P1ZkZf6MGOMz3ARYBhMAnGcnxrv/qmlFGdI3QRAia',	-85762800,	0,	1634127078);

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
  `uid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `role` int(3) DEFAULT NULL,
  UNIQUE KEY `uid_2` (`uid`,`gid`),
  KEY `uid` (`uid`),
  KEY `gid` (`gid`),
  CONSTRAINT `users_groups_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_groups_ibfk_2` FOREIGN KEY (`gid`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users_groups` (`uid`, `gid`, `role`) VALUES
(2,	4,	70),
(1,	NULL,	90);

-- 2021-11-23 12:31:08
